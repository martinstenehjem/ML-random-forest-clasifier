import numpy as np
from typing import Self


def count(y: np.ndarray) -> np.ndarray:
    """
    Count unique values in y and return the proportions of each class.
    Example:
        count(np.array([3, 0, 0, 1, 1, 1, 2, 2, 2, 2])) -> np.array([0.1, 0.3, 0.4, 0.2])
    """
    unique, counts = np.unique(y, return_counts=True)
    return counts / len(y)  


def gini_index(y: np.ndarray) -> float:
    """
    Return the Gini Index of a given NumPy array y.
    The forumla for the Gini Index is 1 - sum(probs^2), where probs are the proportions of each class in y.
    Example:
        gini_index(np.array([1, 1, 2, 2, 3, 3, 4, 4])) -> 0.75
    """
    probs_squared = [num**2 for num in count(y)] 
    return 1 - sum(probs_squared)


def entropy(y: np.ndarray) -> float:
    """
    Return the entropy of a given NumPy array y.
    """
    probs = count(y)
    return - np.sum(probs * np.log2(probs))
    

def split(x: np.ndarray, value: float) -> np.ndarray:
    """
    Return a boolean mask for the elements of x satisfying x <= value.
    Example:
        split(np.array([1, 2, 3, 4, 5, 2]), 3) -> np.array([True, True, True, False, False, True])
    """
    return x<=value


def most_common(y: np.ndarray) -> int:
    """
    Return the most common element in y.
    Example:
        most_common(np.array([1, 2, 2, 3, 3, 3, 4, 4, 4, 4])) -> 4
    """
    counts = np.bincount(y)
    return np.argmax(counts)



class Node:
    """
    A class to represent a node in a decision tree.
    If value != None, then it is a leaf node and predicts that value, otherwise it is an internal node (or root).
    The attribute feature is the index of the feature to split on, threshold is the value to split at,
    and left and right are the left and right child nodes.
    """

    def __init__(
        self,
        feature: int = 0,
        threshold: float = 0.0,
        left: int | Self | None = None,
        right: int | Self | None = None,
        value: int | None = None,
    ) -> None:
        self.feature = feature
        self.threshold = threshold
        self.left = left
        self.right = right
        self.value = value


    def is_leaf(self) -> bool:
        # Return True iff the node is a leaf node
        return self.value is not None



class DecisionTree:
    def __init__(
        self,
        max_depth: int | None = None,
        criterion: str = "entropy",
        max_features: None = None,
        random_state: int = 0
    ) -> None:
        self.root = None
        self.criterion = criterion
        self.max_depth = max_depth
        self.max_features = max_features
        self.rng = np.random.default_rng(random_state)


    def info_gain(self, X, y): # returns the calculated information gain and the threshold to split at
        threshold = np.mean(X)
        left = split(X, threshold)
        right = ~left
        left_y = y[left]
        right_y = y[right]
        if len(left_y) == 0 or len(right_y) == 0:
            return 0, None
        if self.criterion == "gini":
            parent_impurity = gini_index(y)
            impurity_left, impurity_right = gini_index(left_y), gini_index(right_y)
        else:
            parent_impurity = entropy(y)
            impurity_left, impurity_right = entropy(left_y), entropy(right_y)
        w_left, w_right = len(left_y) / len(y), len(right_y) / len(y)

        return parent_impurity - (w_left*impurity_left + w_right*impurity_right), threshold


    def find_best_split(self, X, y):
        features_num = X.shape[1]
        if self.max_features is None:
            n_feat = features_num
        elif self.max_features == "sqrt":
            n_feat = int(np.sqrt(np.shape(X)[1]))
        else:
            n_feat = int(np.log2(np.shape(X)[1]))
        features = self.rng.choice(features_num, size=n_feat, replace=False)
        max_ig = -1
        best_feature_index = None
        best_threshold = None
        for index in features:
            ig, threshold = self.info_gain(X[:, index], y)
            if ig > max_ig:
                max_ig = ig
                best_feature_index = index
                best_threshold = threshold
        if best_threshold is None:
                return None, None

        return best_feature_index, best_threshold
        

    def build_tree(self, X: np.ndarray, y: np.ndarray, depth=0):    
        if len(np.unique(y)) == 1:
            return Node(value=y[0])

        if self.max_depth is not None and depth >= self.max_depth:
            return Node(value=most_common(y))
        
        feature_index, threshold = self.find_best_split(X, y)
        
        if feature_index is None:
            return Node(value=most_common(y))
        
        below_threshold = split(X[:, feature_index], threshold)
        above_threshold = ~below_threshold

        left_X, left_y = X[below_threshold], y[below_threshold]
        right_X, right_y = X[above_threshold], y[above_threshold]
        
        left_subtree = self.build_tree(left_X, left_y, depth + 1)
        right_subtree = self.build_tree(right_X, right_y, depth + 1)

        return Node(feature=feature_index, threshold=threshold, left=left_subtree, right=right_subtree)


    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
    ):
        """
        This functions learns a decision tree given (continuous) features X and (integer) labels y.
        """
        self.root = self.build_tree(X, y)

    
    def traverse_tree(self, X, node):
        if node.is_leaf():
            return node.value
        if X[node.feature] <= node.threshold:
            return self.traverse_tree(X, node.left)
        else:
            return self.traverse_tree(X, node.right)

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Given a NumPy array X of features, return a NumPy array of predicted integer labels.
        """
        return np.array([self.traverse_tree(x, self.root) for x in X])

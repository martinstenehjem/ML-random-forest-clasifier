import numpy as np
from decision_tree import DecisionTree

class RandomForest:
    def __init__(
        self,
        n_estimators: int = 100,
        max_depth: int = 5,
        criterion: str = "entropy",
        max_features: None | str = "sqrt",
        random_state: int=0
    ) -> None:
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.criterion = criterion
        self.max_features = max_features
        self.trees = []
        self.random_state = random_state
        self.rng = np.random.default_rng(random_state)


    def bootstrapping(self, X, y):
        indices = self.rng.choice(X.shape[0], size=X.shape[0], replace=True)

        return X[indices], y[indices]


    def fit(self, X: np.ndarray, y: np.ndarray):
        for i in range(self.n_estimators):
            bootstrapped_X, bootstrapped_y = self.bootstrapping(X, y)
            tree = DecisionTree(max_depth=self.max_depth, criterion=self.criterion, max_features="sqrt", random_state=self.random_state)
            
            tree.fit(bootstrapped_X, bootstrapped_y)
            self.trees.append(tree)


    def predict(self, X: np.ndarray) -> np.ndarray:
        predictions = np.array([tree.predict(X) for tree in self.trees])
        majority_votes = np.array([np.bincount(predictions[:, i]).argmax() for i in range(predictions.shape[1])])
        return majority_votes
